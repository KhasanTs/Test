package ru.ruvideohub.app.state

import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import ru.ruvideohub.app.model.Movie
import ru.ruvideohub.app.model.PlaybackOption
import ru.ruvideohub.app.model.VideoSearchResult
import ru.ruvideohub.app.network.FilmixClient
import ru.ruvideohub.app.network.HdrezkaClient
import ru.ruvideohub.app.network.KinopoiskClient
import ru.ruvideohub.app.network.MailClient
import ru.ruvideohub.app.network.RutubeClient
import ru.ruvideohub.app.network.VkClient

class MainState(private val prefs: SharedPreferences) {

    private val rutube = RutubeClient()
    private val kp = KinopoiskClient(prefs)
    private val vk = VkClient(prefs)
    private val mail = MailClient()
    private val hdrezka = HdrezkaClient()
    private val filmix = FilmixClient(prefs)

    var query by mutableStateOf("")
    var selectedSource by mutableStateOf(
        prefs.getString("selected_source", "rutube").orEmpty()
    )

    var results by mutableStateOf<List<Movie>>(emptyList())
    var selected by mutableStateOf<Movie?>(null)
    var options by mutableStateOf<List<PlaybackOption>>(emptyList())
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    var favorites by mutableStateOf(loadIds("favorites"))
    var history by mutableStateOf(loadIds("history"))

    private fun loadIds(key: String): Set<String> =
        prefs.getStringSet(key, emptySet()).orEmpty()

    private fun saveIds(key: String, value: Set<String>) =
        prefs.edit().putStringSet(key, value).apply()

    fun selectSource(key: String) {
        selectedSource = key
        prefs.edit().putString("selected_source", key).apply()
        results = emptyList()
        error = null
    }

    suspend fun search() {
        val q = query.trim()

        if (q.isBlank()) {
            results = emptyList()
            error = "Введите запрос"
            return
        }

        loading = true
        error = null
        results = emptyList()

        try {
            val result = when (selectedSource) {
                "rutube" -> rutube.search(q)
                "vk" -> vk.search(q)
                "mail" -> mail.search(q)
                "hdrezka" -> hdrezka.search(q)
                "filmix" -> filmix.search(q)
                "ok" -> VideoSearchResult(
                    emptyList(),
                    "Поиск OK пока недоступен без подтверждённого API"
                )
                else -> VideoSearchResult(emptyList(), "Источник не выбран")
            }

            results = result.movies
            if (result.movies.isEmpty())
                error = result.error ?: "Ничего не найдено"
        } catch (_: Exception) {
            error = when (selectedSource) {
                "rutube" -> "RUTUBE: ошибка соединения"
                "vk" -> "VK: проверьте access_token"
                "mail" -> "MAIL.RU: ошибка поиска"
                "hdrezka" -> "HDREZKA: зеркало недоступно"
                "filmix" -> "FILMIX: API недоступен"
                else -> "Ошибка поиска"
            }
            results = emptyList()
        } finally {
            loading = false
        }
    }

    suspend fun open(movie: Movie) {
        loading = true
        error = null

        try {
            val playback = when {
                movie.id.startsWith("rutube:") -> rutube.playback(movie)
                movie.id.startsWith("mail:") -> mail.playback(movie)
                movie.id.startsWith("hdrezka:") -> hdrezka.playback(movie)
                movie.id.startsWith("filmix:") -> filmix.playback(movie)
                else -> movie.options
            }

            selected = movie.copy(options = playback)
            options = playback

            history = history.toMutableSet().apply { add(movie.id) }
            saveIds("history", history)
        } finally {
            loading = false
        }
    }

    fun toggleFavorite() {
        val m = selected ?: return
        favorites = favorites.toMutableSet().apply {
            if (!add(m.id)) remove(m.id)
        }
        saveIds("favorites", favorites)
    }
}
