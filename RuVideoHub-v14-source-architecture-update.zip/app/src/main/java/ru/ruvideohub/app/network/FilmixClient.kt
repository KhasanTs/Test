package ru.ruvideohub.app.network

import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import ru.ruvideohub.app.model.Movie
import ru.ruvideohub.app.model.PlaybackOption
import ru.ruvideohub.app.model.VideoSearchResult
import java.net.URLEncoder
import java.util.Base64

class FilmixClient(private val prefs: SharedPreferences) : VideoSourceClient {

    private val http = OkHttpClient()

    private val apiHosts = listOf(
        "https://filmixapp.cyou/api/v2",
        "http://filmixapp.cyou/api/v2"
    )

    private fun get(url: String): String? {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "RuVideoHub/14 Android")
            .build()

        return runCatching {
            http.newCall(request).execute().use {
                if (it.isSuccessful) it.body?.string() else null
            }
        }.getOrNull()
    }

    private fun post(url: String, form: Map<String, String>): String? {
        val body = FormBody.Builder().apply {
            form.forEach { (k, v) -> add(k, v) }
        }.build()

        val request = Request.Builder()
            .url(url)
            .post(body)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
            .build()

        return runCatching {
            http.newCall(request).execute().use {
                if (it.isSuccessful) it.body?.string() else null
            }
        }.getOrNull()
    }

    override suspend fun search(query: String): VideoSearchResult =
        withContext(Dispatchers.IO) {
            val encoded = URLEncoder.encode(query, "UTF-8")

            for (base in apiHosts) {
                val raw = get("$base/search?q=$encoded") ?: continue
                val root = runCatching { JSONObject(raw) }.getOrNull() ?: continue

                val array = root.optJSONArray("results")
                    ?: root.optJSONArray("data")
                    ?: continue

                val movies = mutableListOf<Movie>()

                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val id = item.optInt(
                        "id",
                        item.optString("id").toIntOrNull() ?: 0
                    )
                    val title = item.optString("title")
                        .ifBlank { item.optString("name") }

                    if (id == 0 || title.isBlank()) continue

                    movies += Movie(
                        id = "filmix:$id",
                        title = title,
                        originalTitle = item.optString("original_title"),
                        year = item.optInt("year", 0).takeIf { it > 0 },
                        source = "FILMIX"
                    )
                }

                if (movies.isNotEmpty())
                    return@withContext VideoSearchResult(movies)
            }

            VideoSearchResult(emptyList(), "FILMIX: API поиска недоступен")
        }

    override suspend fun playback(movie: Movie): List<PlaybackOption> =
        withContext(Dispatchers.IO) {
            val id = movie.id.removePrefix("filmix:")
                .toIntOrNull() ?: return@withContext emptyList()

            val mirror = prefs.getString("filmix_mirror", "https://filmix.my")
                .orEmpty().trimEnd('/')

            val response = post(
                "$mirror/api/movies/player-data",
                mapOf("id" to id.toString())
            ) ?: return@withContext emptyList()

            val json = runCatching { JSONObject(response) }.getOrNull()
                ?: return@withContext emptyList()

            val result = mutableListOf<PlaybackOption>()
            val iterator = json.keys()

            while (iterator.hasNext()) {
                val translation = iterator.next()
                val encoded = json.optString(translation)
                if (encoded.isBlank()) continue

                val decoded = runCatching {
                    Base64.getDecoder().decode(
                        encoded.removePrefix("#2").replace("\\/", "/")
                    ).toString(Charsets.UTF_8)
                }.getOrElse { encoded }

                Regex("""https?://[^\s"'\\]+""")
                    .findAll(decoded)
                    .forEach {
                        result += PlaybackOption(
                            source = "FILMIX",
                            label = translation,
                            url = it.value,
                            audio = translation,
                            mimeType = "video/mp4"
                        )
                    }
            }

            result.distinctBy { it.url }
        }
}
