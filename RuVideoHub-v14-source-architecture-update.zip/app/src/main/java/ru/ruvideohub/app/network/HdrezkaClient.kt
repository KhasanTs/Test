package ru.ruvideohub.app.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import ru.ruvideohub.app.model.Movie
import ru.ruvideohub.app.model.PlaybackOption
import ru.ruvideohub.app.model.VideoSearchResult
import java.net.URLEncoder
import java.util.Base64

class HdrezkaClient : VideoSourceClient {

    private val http = OkHttpClient()

    private val hosts = listOf(
        "https://hdrezka.ag",
        "https://hdrezka.co",
        "https://rezka.ag",
        "https://rezka-ua.tv",
        "https://hdrzk.org"
    )

    private fun request(
        host: String,
        url: String,
        method: String = "GET",
        body: okhttp3.RequestBody? = null
    ): String? {
        val builder = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126 Mobile")
            .header("Accept-Language", "ru-RU,ru;q=0.9,en;q=0.8")
            .header("Referer", "$host/")
            .header("X-Requested-With", "XMLHttpRequest")

        if (method == "POST") builder.post(body ?: FormBody.Builder().build())

        return runCatching {
            http.newCall(builder.build()).execute().use {
                if (it.isSuccessful) it.body?.string() else null
            }
        }.getOrNull()
    }

    private fun findHost(): String? =
        hosts.firstOrNull { host -> request(host, "$host/") != null }

    override suspend fun search(query: String): VideoSearchResult =
        withContext(Dispatchers.IO) {
            val host = findHost()
                ?: return@withContext VideoSearchResult(emptyList(), "HDREZKA: рабочее зеркало не найдено")

            val q = URLEncoder.encode(query, "UTF-8")
            val html = request(host, "$host/engine/ajax/search.php?q=$q")
                ?: return@withContext VideoSearchResult(emptyList(), "HDREZKA: поиск недоступен")

            val result = mutableListOf<Movie>()
            val regex = Regex(
                """<a[^>]+href=["']([^"']+)["'][^>]*>.*?<span[^>]+class=["']enty["'][^>]*>(.*?)</span>.*?</a>""",
                setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
            )

            regex.findAll(html).take(30).forEach { match ->
                val url = match.groupValues[1]
                val title = match.groupValues[2]
                    .replace(Regex("<[^>]+>"), "")
                    .replace("&quot;", "\"")
                    .replace("&amp;", "&")
                    .trim()

                if (title.isBlank() || url.isBlank()) return@forEach

                val absolute = if (url.startsWith("http")) url
                else host.trimEnd('/') + "/" + url.trimStart('/')

                result += Movie(
                    id = "hdrezka:$absolute",
                    title = title,
                    source = "HDREZKA",
                    options = listOf(
                        PlaybackOption(
                            source = "HDREZKA",
                            label = "Открыть",
                            url = absolute,
                            mimeType = "text/html"
                        )
                    )
                )
            }

            if (result.isEmpty())
                VideoSearchResult(emptyList(), "HDREZKA: результаты не распознаны")
            else
                VideoSearchResult(result)
        }

    override suspend fun playback(movie: Movie): List<PlaybackOption> =
        withContext(Dispatchers.IO) {
            val page = movie.id.removePrefix("hdrezka:")
            val host = page.substringBefore("/", missingDelimiterValue = page)

            val html = request(host, page)
                ?: return@withContext movie.options

            val id = Regex("""initCDN(?:Movies|Series)Events\((\d+)""")
                .find(html)?.groupValues?.getOrNull(1)
                ?: Regex("""data-post_id=["'](\d+)""")
                    .find(html)?.groupValues?.getOrNull(1)
                ?: return@withContext movie.options

            val translator = Regex("""data-translator_id=["'](\d+)""")
                .find(html)?.groupValues?.getOrNull(1)
                ?: Regex("""translator_id['"]?\s*[:=]\s*['"]?(\d+)""")
                    .find(html)?.groupValues?.getOrNull(1)
                ?: "0"

            val body = FormBody.Builder()
                .add("id", id)
                .add("translator_id", translator)
                .add("is_camrip", "0")
                .add("is_ads", "0")
                .add("is_director", "0")
                .add("favs", "")
                .add("action", "get_movie")
                .build()

            val response = request(
                host,
                "$host/ajax/get_cdn_series/?t=${System.currentTimeMillis()}",
                "POST",
                body
            ) ?: return@withContext movie.options

            val encoded = Regex(""""url"\s*:\s*"([^"]+)"""")
                .find(response)?.groupValues?.getOrNull(1)
                ?: return@withContext movie.options

            val decoded = decodeRezka(encoded)
            val options = mutableListOf<PlaybackOption>()

            Regex("""\[(\d{3,4}p(?: Ultra)?)\]\s*(https?://[^,\s]+)""")
                .findAll(decoded)
                .forEach { match ->
                    val quality = match.groupValues[1]
                    options += PlaybackOption(
                        source = "HDREZKA",
                        label = quality,
                        url = match.groupValues[2],
                        quality = quality,
                        mimeType = "video/mp4"
                    )
                }

            options.ifEmpty {
                listOf(
                    PlaybackOption(
                        source = "HDREZKA",
                        label = "Авто",
                        url = page,
                        mimeType = "text/html"
                    )
                )
            }
        }

    private fun decodeRezka(value: String): String {
        val s = value.replace("\\/", "/").replace("\\u002F", "/")
        val clean = if (s.startsWith("#h")) s.removePrefix("#h") else s
        return runCatching {
            Base64.getDecoder().decode(clean).toString(Charsets.UTF_8)
        }.getOrElse { clean }
    }
}
