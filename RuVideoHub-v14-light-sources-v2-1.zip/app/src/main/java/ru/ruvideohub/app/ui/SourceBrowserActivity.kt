package ru.ruvideohub.app.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.Button
import android.widget.EditText
import android.view.ViewGroup
import android.graphics.Color
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import ru.ruvideohub.app.util.SecurePrefs
import java.net.URLEncoder

/**
 * Простая встроенная страница источника. Для зеркальных каталогов пользователь
 * указывает свой адрес в настройках, после чего поиск выполняется непосредственно
 * на этом сайте. Никакого обхода DRM здесь нет: WebView работает как обычный браузер.
 */
class SourceBrowserActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var search: EditText
    private var key: String = ""
    private var mirror: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        key = intent.getStringExtra(EXTRA_KEY).orEmpty()
        val initialQuery = intent.getStringExtra(EXTRA_QUERY).orEmpty()
        mirror = SecurePrefs.get(this)
            .getString(mirrorKey(key), "").orEmpty().trim().trimEnd('/')

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(12, 12, 12, 8)
        }
        search = EditText(this).apply {
            hint = "Название фильма или сериала"
            singleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setText(initialQuery)
        }
        val go = Button(this).apply { text = "Искать" }
        bar.addView(search, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(go, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(bar)

        web = WebView(this)
        configureWebView()
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        val doSearch = { loadSearch(search.text.toString()) }
        go.setOnClickListener { doSearch() }
        search.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_SEARCH) { doSearch(); true } else false
        }
        if (initialQuery.isNotBlank()) loadSearch(initialQuery) else web.loadUrl(homeUrl())
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.userAgentString = DESKTOP_UA
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return false
            }
        }
    }

    private fun loadSearch(q: String) {
        val query = q.trim()
        if (query.isBlank()) return
        val url = searchUrl(key, mirror, query)
        if (url == null) {
            Toast.makeText(this, "Для $key укажите зеркало в Настройки → Источники", Toast.LENGTH_LONG).show()
            return
        }
        web.loadUrl(url)
    }

    private fun homeUrl(): String = when (key) {
        "rutube" -> "https://rutube.ru/"
        "vk" -> "https://vkvideo.ru/"
        "ok" -> "https://ok.ru/video"
        "mail" -> "https://my.mail.ru/video/"
        else -> mirror.ifBlank { "about:blank" }
    }

    companion object {
        private const val EXTRA_KEY = "source_key"
        private const val EXTRA_QUERY = "query"
        private const val DESKTOP_UA = "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36"

        fun start(context: android.content.Context, key: String, query: String) {
            context.startActivity(android.content.Intent(context, SourceBrowserActivity::class.java)
                .putExtra(EXTRA_KEY, key).putExtra(EXTRA_QUERY, query))
        }

        private fun mirrorKey(key: String): String = when (key) {
            "seena" -> "seena_mirror"
            "zona" -> "zona_mirror"
            "hdrezka" -> "hdrezka_mirror"
            "filmix" -> "filmix_mirror"
            else -> ""
        }

        private fun enc(q: String) = URLEncoder.encode(q, "UTF-8")

        private fun searchUrl(key: String, mirror: String, q: String): String? {
            val e = enc(q)
            return when (key) {
                "rutube" -> "https://rutube.ru/search/?query=$e"
                "vk" -> "https://vkvideo.ru/search?q=$e"
                "ok" -> "https://ok.ru/video/search?st.query=$e"
                "mail" -> "https://my.mail.ru/video/search?q=$e"
                "hdrezka" -> mirror.takeIf { it.isNotBlank() }?.let { "$it/search/?do=search&subaction=search&story=$e" }
                "filmix" -> mirror.takeIf { it.isNotBlank() }?.let { "$it/search/$e/" }
                "seena" -> mirror.takeIf { it.isNotBlank() }?.let { "$it/search/$e" }
                "zona" -> mirror.takeIf { it.isNotBlank() }?.let { "$it/search/$e" }
                else -> null
            }
        }
    }
}
